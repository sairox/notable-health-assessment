package com.springboot.assessmentwebapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssessmentWebAppApplicationTests {

    @Test
    void contextLoads() {
    }

}
