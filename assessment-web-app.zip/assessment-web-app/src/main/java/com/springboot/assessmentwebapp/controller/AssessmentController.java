package com.springboot.assessmentwebapp.controller;

import com.springboot.assessmentwebapp.model.Doctor;
import com.springboot.assessmentwebapp.model.Patient;
import com.springboot.assessmentwebapp.service.DoctorService;
import com.springboot.assessmentwebapp.service.PatientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class AssessmentController {

    @Autowired
    private final DoctorService doctorService;

    @Autowired
    private final PatientService patientService;

    public AssessmentController(DoctorService doctorService, PatientService patientService) {
        this.doctorService = doctorService;
        this.patientService = patientService;
    }

    //
    @GetMapping("/doctors")
    public List<Doctor> getAllDoctors(){
        return doctorService.getAllDoctors();
    }

    @PostMapping("/insertDoctor")
    public ResponseEntity<Doctor> addDoctor(@RequestBody Doctor doctor){
        return new ResponseEntity<>(doctorService.saveDoctors(doctor), HttpStatus.CREATED);
    }

    @PostMapping("/insertPatient/{id}")
    public ResponseEntity<Patient> addPatient(@RequestBody Patient patient, @PathVariable("id") Long id){
        return new ResponseEntity<>(patientService.addAppointment(patient, id), HttpStatus.CREATED);
    }

}
