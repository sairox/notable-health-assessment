package com.springboot.assessmentwebapp.repository;

import com.springboot.assessmentwebapp.model.Doctor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface DoctorRepository extends JpaRepository<Doctor, Long> {

    @Query(value = "SELECT distinct A FROM Doctor A WHERE A.doctorId=?1")
    public Doctor findDoctorById(@Param("doctor_id") long id);
}
