package com.springboot.assessmentwebapp.service.impl;

import com.springboot.assessmentwebapp.model.Doctor;
import com.springboot.assessmentwebapp.repository.DoctorRepository;
import com.springboot.assessmentwebapp.service.DoctorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DoctorServiceImpl implements DoctorService {

    private final DoctorRepository doctorRepository;

    @Autowired
    public DoctorServiceImpl(DoctorRepository doctorRepository){
        this.doctorRepository = doctorRepository;
    }

    @Override
    public Doctor saveDoctors(Doctor doctors){
        return doctorRepository.save(doctors);
    }

    @Override
    public List<Doctor> getAllDoctors() {
        return doctorRepository.findAll();
    }
}
