package com.springboot.assessmentwebapp.service.impl;

import com.springboot.assessmentwebapp.model.Doctor;
import com.springboot.assessmentwebapp.model.Patient;
import com.springboot.assessmentwebapp.repository.DoctorRepository;
import com.springboot.assessmentwebapp.repository.PatientRepository;
import com.springboot.assessmentwebapp.service.PatientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class PatientServiceImpl implements PatientService {

    private final PatientRepository patientRepository;
    private final DoctorRepository doctorRepository;

    @Autowired
    public PatientServiceImpl(PatientRepository patientRepository, DoctorRepository doctorRepository){
        this.patientRepository = patientRepository;
        this.doctorRepository = doctorRepository;
    }

    @Override
    public Patient addAppointment(Patient patientRequest, Long doctorId) {

        Doctor doctor = doctorRepository.findDoctorById(doctorId);

        if(doctor.getPatients().size() >= 3){
            throw new RuntimeException();
        }

        doctor.getPatients().add(patientRequest);

        return patientRepository.save(patientRequest);
    }
}
