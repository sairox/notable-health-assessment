package com.springboot.assessmentwebapp.service;

import com.springboot.assessmentwebapp.model.Doctor;

import java.util.List;

public interface DoctorService {

    Doctor saveDoctors(Doctor doctors);
    List<Doctor> getAllDoctors();
}
