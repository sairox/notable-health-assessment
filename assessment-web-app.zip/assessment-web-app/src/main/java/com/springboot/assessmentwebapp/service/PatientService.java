package com.springboot.assessmentwebapp.service;

import com.springboot.assessmentwebapp.model.Doctor;
import com.springboot.assessmentwebapp.model.Patient;

public interface PatientService {

    Patient addAppointment(Patient patientRequest, Long doctorId);
}
